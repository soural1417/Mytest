from django.apps import AppConfig


class ApponeConfig(AppConfig):
    name = 'appone'
